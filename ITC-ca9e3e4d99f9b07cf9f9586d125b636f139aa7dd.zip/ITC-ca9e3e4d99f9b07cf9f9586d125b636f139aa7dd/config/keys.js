// add this file to .gitignore

module.exports = {
  google: {
    clientID: '390879348958-aafkfja9l2inu4lkhus668gunp9kosos.apps.googleusercontent.com',
    clientSecret: 'oVmsdLuFMI16dBL0ivNOMyf2'
  },
  mongodb: {
    // dbURI: 'mongodb+srv://user02:Aa66787785@cluster0-hmsvk.gcp.mongodb.net/tingStore?retryWrites=true'
    dbURI: 'mongodb+srv://itcstore:Aa55559294@cluster0.k0kof.gcp.mongodb.net/?retryWrites=true&w=majority'
    // dbURI: 'mongodb+srv://user2023:123789@cluster0.k0kof.gcp.mongodb.net/?retryWrites=true&w=majority'
  },
  admin: {
    Id: 'eng.dugaim@gmail.com'
  },
  session: {
    cookieKey: 'abdulrahmanawesomeiguess'
  }
};